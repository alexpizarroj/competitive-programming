/*
 * Outputs random token.
 *
 * Token contains latin letters and digits and have length 
 * between 1 and 1000 characters, inclusive.
 *
 * To generate different values, call "swgen.exe <weight>".
 * See "iwgen.cpp" and "wnext()" documentation for details.
 * For example, "swgen.exe -1000" generates short strings and "swgen.exe 1000"
 * generates long strings.
 * 
 * It is typical behaviour of testlib generator to setup randseed by command line.
 */

#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

vector<vector<int>> GetTree(const vector<int> &s)
{
  const int n = s.size();
  vector<vector<int>> T(n + 3, vector<int>());

  vector<int> deg(n + 3, 1);
  for(int x : s)
    deg[x] += 1;

  set<pair<int,int>> st;
  for(int i = 1; i <= n + 2; i++)
    st.insert(make_pair(deg[i], i));

  for(int i = 0; i < n; i++)
  {
    int u = st.begin()->second;
    int v = s[i];
    assert(deg[u] == 1);

    T[u].push_back(v);
    T[v].push_back(u);

    deg[u] -= 1;
    st.erase(st.begin());
    st.erase(make_pair(deg[v], v));
    if (deg[v] > 1)
      st.insert(make_pair(deg[v] - 1, v));
    deg[v] -= 1;
  }

  int t0 = 0, t1 = 0;
  for(int i = 1; i <= n + 2; i++)
    if (deg[i] == 1)
    {
      if (t0 == 0)
      {
        t0 = i;
      }
      else
      {
        t1 = i;
        break;
      }
    }
  deg[t0] -= 1, deg[t1] -= 1;
  T[t0].push_back(t1);
  T[t1].push_back(t0);

  return move(T);
}

vector<int> GenerateTest(const int n)
{
  vector<int> s(n - 2);
  for(int i = 0; i < (int)s.size(); i++)
    s[i] = rnd.next(1, n);

  vector<vector<int>> T = GetTree(s);
  vector<int> parent(n, 0);
  queue<int> q;
  q.push(1);
  while (!q.empty())
  {
    const int u = q.front();
    q.pop();
    for(int i = 0; i < (int)T[u].size(); i++)
    {
      const int v = T[u][i];
      if (parent[u-1] == v)
        continue;

      parent[v-1] = u;
      q.push(v);
    }
  }

  return move(parent);
}

int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);

    int n;
    sscanf(argv[1], "%d", &n);
    assert(n >= 3);

    const int test_cases = 20;
    cout << test_cases << endl;

    for(int i = 1; i <= test_cases; i++)
    {
      vector<int> test = GenerateTest(n);
      cout << n << endl;
      for(int i = 0; i < n; i++)
        cout << test[i] << " \n"[i == n - 1];
    }

    return 0;
}
