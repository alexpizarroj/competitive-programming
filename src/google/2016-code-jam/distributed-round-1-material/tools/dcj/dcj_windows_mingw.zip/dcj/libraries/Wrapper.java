class Wrapper {
  public static void main(String[] args) {
    System.loadLibrary("message");
    Main.main(args);
  }
}
