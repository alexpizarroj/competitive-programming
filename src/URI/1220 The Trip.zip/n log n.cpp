#include <cstdio>
#include <algorithm>
#define fupi(i,a,b) for(int i = (a); (i) <= int(b); ++i)
using namespace std;

int main()
{
#ifdef LOCAL
	freopen("input.txt", "r", stdin);
#endif

    const int cstMax = 1000;
	int n, sum, d, c, x, ans;
	int v[cstMax+5];

	while ( scanf("%d", &n), n > 0 )
	{
        sum = 0;
        fupi(i,1,n)
        {
            scanf("%d.%d", &d, &c);
            v[i] = d*100 + c;
            sum += v[i];
        }

        x = sum / n;
        c = (x+1)*n - sum; // amount of values that have to be set to x
        ans = 0;
        sort(v+1, v+1+n);
        fupi(i,1,c)   ans += abs( x - v[i] );
        fupi(i,c+1,n) ans += abs( x+1 - v[i] );
        ans >>= 1;

        printf("$%d.%02d\n", ans/100, ans%100);
	}

    return 0;
}
