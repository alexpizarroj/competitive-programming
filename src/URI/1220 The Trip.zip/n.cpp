#include <cstdio>
#include <algorithm>
#define fupi(i,a,b) for(int i = (a); (i) <= int(b); ++i)
using namespace std;

int main()
{
#ifdef LOCAL
	freopen("input.txt", "r", stdin);
#endif

    const int cstMax = 1000;
	int n, sum, d, c, x, ans;
	int v[cstMax+5];
    bool round;
    int more, less;

	while ( scanf("%d", &n), n > 0 )
	{
        sum = 0;
        fupi(i,1,n)
        {
            scanf("%d.%d", &d, &c);
            v[i] = d*100 + c;
            sum += v[i];
        }
        
        x = sum / n;
        round = ( x * n == sum );
        more = less = 0;
        fupi(i,1,n)
        {
            if (  round && v[i] >= x+1 )
                more += v[i] - (x+1);
            else if ( !round && v[i] > x )
                more += v[i] - x;
            else
                less += x - v[i];
        }
        ans = max(more, less);

        printf("$%d.%02d\n", ans/100, ans%100);
	}

    return 0;
}
