import os

wd = os.getcwd() + "\\in"
outexe = "test.exe"
if os.system("g++ main.cpp -o " + outexe) != 0:
    print "Compilation Error. Testing aborted."
else:
    for f in os.listdir(wd):
        print "Running test '" + f + "'... ",
        input = wd + '\\' + f
        output = "ans\\" + f
        os.system(outexe + ' < "' + input + '" > "' + output + '"')
        print "Completed."
        os.system('diff "' + os.getcwd() + "\\out\\" + f + '" "' + output + '"')
    os.remove(os.getcwd() + '\\' + outexe)
    print "DONE."
    
os.system("pause")