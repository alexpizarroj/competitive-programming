// Solution Author: alexpizarroj
// STRATEGY
//   dp[x][y] : Returns whether city "x" dominates city "y"
// EXPLANATION
//   A city x dominates another city y if every path
//   from Logville to y must pass through x (articulation vertex?)
//     dp[1][x] = false;
//     dp[x][x] = true;
//     dp[x][y] = min[w : w->y] dp[x][w]; for x != y
//
#include <cstring>
#include <cstdio>
#define fup(i,a,b) for(int i = (a); (i) < int(b); ++i)
#define fupi(i,a,b) for(int i = (a); (i) <= int(b); ++i)
bool dp[1005][1005];
int adjlist[1005][1005], degree[1005];

int main()
{
    int n, m, x, y, ans, vec[1005];
    bool taken[1005];
    
    while ( ~scanf("%d %d", &n, &m) )
    {
        memset(degree, 0, (n+1)*(sizeof degree[0]));
        memset(taken, 0, (n+1)*(sizeof taken[0]));
        while( m-- )
        {
            scanf("%d %d", &x, &y);
            adjlist[y][degree[y]++] = x;
        }
               
        ans = 0;
        fupi(i,2,n)
        {
            if ( taken[i] ) continue;
            dp[i][i] = true;
            
            vec[0] = i, x = 1;
            fupi(j,i+1,n)
            {
                bool depends = true;
                fup(k,0,degree[j])
                {
                    int v = adjlist[j][k];
                    if ( !dp[i][v] ) { depends = false; break; }
                }
                dp[i][j] = depends;
                if ( depends ) vec[x++] = j;
            }
            fup(i,0,x) taken[vec[i]] = true;
            ans += (x*(x-1))/2;
        }
        ans = (n*(n-1))/2 - ans;
        
        printf("%d\n", ans);
    }
	
    return 0;
}
