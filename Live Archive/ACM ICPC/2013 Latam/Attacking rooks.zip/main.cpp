#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <algorithm>
#include <string>
#define PB push_back
#define MP make_pair
#define ALL(a) (a).begin(), (a).end()
#define MSB(n) ( n <= 0 ? 0 : int(floor(log(n)/log(2))) )
#define fup(i,a,b) for(int i = (a); (i) < int(b); ++i)
#define fupi(i,a,b) for(int i = (a); (i) <= int(b); ++i)
#define foreach(it, a) for(typeof((a).begin()) it=(a).begin(); it != (a).end(); ++it)
#define rforeach(it, a) for(typeof((a).rbegin()) it=(a).rbegin(); it != (a).rend(); ++it)
using namespace std;

typedef vector<int> vi;
// Graph Modeling
const int MAX = 105;
char maze[MAX][MAX];
int row[MAX][MAX], col[MAX][MAX];
vector<vi> lst; // adj list for left elements
vi lema, rima;  // lema = left elements match, rima = right elements match
int n, m;       // n = amount of left elements, m = amount of right elements

bool find_match(int s)
{
    vi from(n, -1); queue<int> q;
    int where, match, next;
    bool found = false;

    q.push(s), from[s] = s;
    while ( !found && !q.empty() )
    {
        where = q.front(); q.pop();
        for(int i = 0; i < (int)lst[where].size(); ++i)
        {
            match = lst[where][i];
            next = rima[match];
            if ( where != next )
            {
                if ( next == -1 ) { found = true; break; }
                if ( from[next] == -1 ) q.push(next), from[next] = where;
            }
        }
    }

    if ( found )
    {
        while (from[where] != where)
        {
           next = lema[where];
           lema[where] = match, rima[match] = where;
           where = from[where], match = next;
        }
        lema[where] = match, rima[match] = where;
    }

    return found;
}

int maximum_matching() // O(V*E)
{
    int ans = 0;
    lema.assign(n, -1), rima.assign(m, -1);
    for(int i = 0; i < n; ++i) ans += find_match(i);
    return ans;
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif

	int x, idr, idc;

    while ( scanf("%d", &x) != EOF )
    {
        getchar();
        fup(i,0,x) gets(maze[i]);
        memset(row, -1, sizeof row);
        memset(col, -1, sizeof col);

        // Row Numbering
        idr = 0;
        fup(i,0,x) fup(j,0,x)
        {
            if ( maze[i][j] == '.' )
            {
                while ( j < x && maze[i][j] == '.' )
                {
                    row[i][j] = idr;
                    ++j;
                }
                ++idr;
            }
        }
        n = idr;
        // Column Numbering
        idc = 0;
        fup(i,0,x) fup(j,0,x)
        {
            if ( maze[i][j] == '.' && col[i][j] == -1 )
            {
                int k = i;
                while ( k < x && maze[k][j] == '.' )
                {
                    col[k][j] = idc;
                    ++k;
                }
                ++idc;
            }
        }
        m = idc;
        // Linking: Left -> Right
        lst.assign(idr, vi());
        fup(i,0,x) fup(j,0,x) if ( maze[i][j] == '.' )
        {
            lst[ row[i][j] ].PB( col[i][j] );
        }

        printf("%d\n", maximum_matching());
    }

    return 0;
}
